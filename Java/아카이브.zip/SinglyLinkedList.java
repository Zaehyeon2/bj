import java.util.Scanner;

public class SinglyLinkedList {

    private static class Node<Integer> {
        private int element;
        private Node<Integer> next;
        public Node(int e, Node<Integer> n) {
            element = e;
            next = n;
        }
        public int getElement() {
            return element;
        }
        public Node<Integer> getNext() {
            return next;
        }
        public void setNext(Node<Integer> n) {
            next = n;
        }
    }

    private static Node<Integer> head = null;
    private static Node<Integer> tail = null;
    private static int size = 0;
    public SinglyLinkedList(){}

    public static int size() {
        return size;
    }

    public static boolean isEmpty() {
        return size() == 0;
    }

    public static int first() {
        if (isEmpty()) return 0;
        return head.getElement();
    }

    public static int last() {
        if (isEmpty()) return 0;
        return tail.getElement();
    }

    public static void addFirst(Integer e) {
        head = new Node<>(e, head);
        if (size == 0) {
            tail = head;
        }
        size++;
    }

    public static void addLast(Integer e) {
        Node<Integer> newest = new Node<>(e, null);
        if (isEmpty()) {
            head = newest;
        }
        else {
            tail.setNext(newest);
        }
        size++;
        tail = newest;
    }

    public static int removeFirst(){
        if (isEmpty()) return 0;
        int answer = head.getElement();
        head = head.getNext();
        size--;
        if (size == 0) {
            tail = null;
        }
        return answer;
    }

    public static void insertion(Integer e, int idx){
        if (idx > size || idx < 0) {
            System.out.println("Index OverFlow!");
            return;
        }
        if (idx == size){
            addLast(e);
            return;
        }
        if (idx == 0){
            addFirst(e);
            return;
        }
        Node<Integer> tmp = head;
        for(int i = 0; i < idx - 1; i++){
            tmp = tmp.getNext();
        }
        Node<Integer> insert = new Node<>(e, tmp.getNext());
        tmp.setNext(insert);
        size++;
    }

    public static void removing(int idx){
        if (size == 0 || idx < 0 || idx > size - 1){
            System.out.println("Error");
            return;
        }
        if (idx == 0){
            removeFirst();
            return;
        }
        Node<Integer> tmp = head;
        for(int i = 0; i < idx - 1; i++){
            tmp = tmp.getNext();
        }
        if (idx == size - 1) {
            tmp.setNext(null);
            size--;
            return;
        }
        tmp.setNext(tmp.getNext().getNext());
        size--;
        if (size == 0) {
            tail = null;
        }
    }

    public static void pall(){
        if (size == 0){
            System.out.println("Not Element in Linked List");
            return;
        }
        Node<Integer> tmp = head;
        System.out.println("Index : 0, Element : " + tmp.getElement());
        for(int i = 0; i < size - 1; i++){
            tmp = tmp.getNext();
            System.out.println("Index : " + (i + 1) + ", Element : " + tmp.getElement());
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("0 = End, 1 = Insert, 2 = Removing, 3 = Print All");
            int Case = sc.nextInt();
            if (Case == 0) {
                System.out.println("Program is End!");
                break;
            }
            else if (Case == 1) {
                System.out.print("Element : ");
                int text = sc.nextInt();
                System.out.print("Index : ");
                int idx = sc.nextInt();
                insertion(text, idx);
            }
            else if (Case == 2) {
              System.out.print("Index : ");
                int idx = sc.nextInt();
                removing(idx);
            }
            else {
                pall();
            }
        }
        sc.close();
    }
}
